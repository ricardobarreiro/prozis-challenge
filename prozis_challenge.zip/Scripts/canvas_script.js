// PROZIS PROJECT - Canvas script

// Canvas
let canvas = document.getElementById('canvas');
FitToContainer(canvas);
let ctx = canvas.getContext('2d');

let animationFrame;

// Function to fit canvas in container div.
function FitToContainer(canvas){
    canvas.style.width='100%';
    canvas.style.height='100%';
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
}

const gravity = 1;

// Function to initialize ball app.
function StartBallApp(clickX, clickY){
    
    // Ball object
    let size = Math.floor(Math.random() * (75) + 1);
    let lossSpeedConstant = 0.1;
    let directionX = Math.round(Math.random()) * 2 - 1;
    let directionY = Math.round(Math.random()) * 2 - 1;
    let vXinit = Math.floor(Math.random() * (20 + 1)) * directionX;
    let vYinit = Math.floor(Math.random() * (20 + 1)) * directionY;
    let startTime = new Date();

    let ball = {
        x: clickX,
        y: clickY,
        vx: vXinit,
        vy: vYinit,
        radius: size,
        color: '#'+Math.floor(Math.random()*16777215).toString(16)
    };

    BallAppLoop();

    // Function to draw the ball with X, Y, Vx and Vy formulas.
    function DrawBall(){

        let atualTime = new Date();
        atualTime = (atualTime - startTime) / 1000;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        // Vy = g*T;
        ball.vy += -(atualTime*gravity); 
        // Vx.
        ball.vx = ball.vx;
        //X & Y.
        // X = X0 + Vx*T
        ball.x = ball.x + (ball.vx * atualTime);
        // Y = Y0 + Vy*T - (g*T^2)*0.5
        ball.y = ball.y + (atualTime*gravity*atualTime) - (0.5*gravity*atualTime*atualTime);

        LossSpeedCalculation(ball);

        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI*2, true);
        ctx.fillStyle = ball.color;
        ctx.fill();
        ctx.closePath();
    }

    //Function to calculate speed lost when the ball hit the limit of canvas. Reduce speed in 10%.
    function LossSpeedCalculation(ball){          
        if(ball.x>=canvas.width-ball.radius){
            ball.x = canvas.width - ball.radius;
            ball.vx = -ball.vx;
            ball.vx = ball.vx - (ball.vx*lossSpeedConstant);
        }
        else if(ball.x<=ball.radius){
            ball.x = ball.radius;
            ball.vx = -ball.vx;
            ball.vx = ball.vx - (ball.vx*lossSpeedConstant); 
        }
        else if(ball.y>=canvas.height-ball.radius){
            ball.y = canvas.height-ball.radius;
            ball.vy = -ball.vy;
            ball.vy = ball.vy - (ball.vy*lossSpeedConstant);
        }
        else if(ball.y<=0+ball.radius){
            ball.y = ball.radius;
            ball.vy = -ball.vy;
            ball.vy = ball.vy - (ball.vy*lossSpeedConstant);
        }   
    }

    // Function to initialize request animation frame.
    function BallAppLoop(){
        animationFrame = window.requestAnimationFrame(BallAppLoop);
        DrawBall();
    }
}

window.addEventListener('click',function(e){
    StartBallApp(e.x,e.y);
});

window.addEventListener('keypress', function (e) {
    if (e.key === 'Enter' || e.code == 'Space') {
        window.cancelAnimationFrame(animationFrame);
    }
});
